//this will store message for one to one

$(document).ready(function() {
		$('#send-msg').click(function(e) {
			e.preventDefault();
			var toId = $("#toId").val();
			var fromId = $("#fromId").val();
			var message = $("#message").val();
			
			$.ajax({
				url : "send-message",
				// type: "post",
				data : {toId,fromId,message},
				cache : false,
				success : function(data) {
					$("#message").val('');
				}
			});
		});
	});

//send message to the group members

$(document).ready(function() {
		$('#send-group-msg').click(function(e) {
			e.preventDefault();
			var toGroupId = $("#toGroupId").val();
			var fromId = $("#fromId").val();
			var message = $("#message").val();
			
			$.ajax({
				url : "send-group-msg",
				// type: "post",
				data : {toGroupId,fromId,message},
				cache : false,
				success : function(data) {
					$("#message").val('');
				}
			});
		});
	});


// this code will auto refresh the chat box of one to one chat

var auto = setInterval(function() {
	$('#chat-content').load('chat-box');
}, 1000000); // refresh every 100 milliseconds


// this code will auto refresh the chat box of group chat

var auto = setInterval(function() {
	$('#groupChatBox').load('group-chat-box');
}, 10); // refresh every 10 milliseconds







