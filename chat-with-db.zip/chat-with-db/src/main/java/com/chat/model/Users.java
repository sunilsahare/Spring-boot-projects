package com.chat.model;

public class Users {

	private String userid;
	private String email;
	private String password;
	private String loginStatus;
	private int uid;
	private String fullName;
	private String dob;
	private String mobile;
	private String city;
	private String regDate;
	private String secQuestion;
	private String answer;
	private String userType;
	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Users(String userid, String email, String password) {
		super();
		this.userid = userid;
		this.email = email;
		this.password = password;
	}

	public Users(String userid, String email, String password, String loginStatus, int uid, String fullName, String dob,
			String mobile, String city, String regDate, String secQuestion, String answer) {
		super();
		this.userid = userid;
		this.email = email;
		this.password = password;
		this.loginStatus = loginStatus;
		this.uid = uid;
		this.fullName = fullName;
		this.dob = dob;
		this.mobile = mobile;
		this.city = city;
		this.regDate = regDate;
		this.secQuestion = secQuestion;
		this.answer = answer;
	}
	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getLoginStatus() {
		return loginStatus;
	}


	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}


	public int getUid() {
		return uid;
	}


	public void setUid(int uid) {
		this.uid = uid;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getRegDate() {
		return regDate;
	}


	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}


	public String getSecQuestion() {
		return secQuestion;
	}


	public void setSecQuestion(String secQuestion) {
		this.secQuestion = secQuestion;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public String getUserType() {
		return userType;
	}


	public void setUserType(String userType) {
		this.userType = userType;
	}


	@Override
	public String toString() {
		return "Users [userid=" + userid + ", email=" + email + ", password=" + password + ", loginStatus="
				+ loginStatus + ", uid=" + uid + ", fullName=" + fullName + ", dob=" + dob + ", mobile=" + mobile
				+ ", city=" + city + ", regDate=" + regDate + ", secQuestion=" + secQuestion + ", answer=" + answer
				+ ", userType=" + userType + "]";
	}


}
