package com.chat.model;

import java.util.Date;

public class Message {

	private int id;
	private String fromId;
	private String toId;
	private String message;
	private String timestamp;
	private int groupId;

	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Message(int id, String fromId, String toId, String message, String timestamp, int groupId) {
		super();
		this.id = id;
		this.fromId = fromId;
		this.toId = toId;
		this.message = message;
		this.timestamp = timestamp;
		this.groupId = groupId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFromId() {
		return fromId;
	}

	public void setFromId(String fromId) {
		this.fromId = fromId;
	}

	public String getToId() {
		return toId;
	}

	public void setToId(String toId) {
		this.toId = toId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

}
