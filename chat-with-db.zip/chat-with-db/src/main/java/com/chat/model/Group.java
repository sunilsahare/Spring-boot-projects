package com.chat.model;

public class Group {

	private int groupId;
	private String createdBy;
	private String createdDate;
	private String groupName;
	private int groupMemberId;
	private String userId;
	private String fullName;

	public Group() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Group(int groupId, String createdBy, String createdDate, String groupName, int groupMemberId,
			String userId) {
		super();
		this.groupId = groupId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.groupName = groupName;
		this.groupMemberId = groupMemberId;
		this.userId = userId;
	}

	public Group(int groupId, String createdBy, String createdDate, String groupName) {
		super();
		this.groupId = groupId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.groupName = groupName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public int getGroupMemberId() {
		return groupMemberId;
	}

	public void setGroupMemberId(int groupMemberId) {
		this.groupMemberId = groupMemberId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Group [groupId=" + groupId + ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", groupName=" + groupName + ", groupMemberId=" + groupMemberId + ", userId=" + userId + "]";
	}

}
