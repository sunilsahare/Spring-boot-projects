package com.chat.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chat.dao.UserDao;
import com.chat.model.Users;
import com.chat.util.EmailUtil;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Autowired
	EmailUtil email;

	// registration done through this code
	@Override
	public String addUser(Users users) {
		String result = userDao.registerUser(users);
		String msg = null;
		String msgBody = "Mr/Mrs. "+users.getFullName()+" ,you are succcessfully registered on Web Chat Messanger.\n "+new Date();
		if (result.equals("success")) {
			email.sendEmail(users.getEmail(), "Registration Successfull", msgBody);
			msg = "Registration Successfull.";
		} 
		else if (result.equals("user-exist")) {
			msg="UserId already exist! Please enter another UserId.";
		} 
		else if (result.equals("fail")) {
			msg = "Registration failed.!!!";
		}
		else {
			msg = "Something went Wrong.!!!Please try again later.";
		}
		return msg;
	}

	// Check user login validity
	@Override
	public String loginUser(String userid, String password) {
		return userDao.validateUser(userid, password);
	}

	@Override
	public String changePassword(String nPass, String userid, String cPass) {
		return userDao.changePass(nPass, userid, cPass);
	}

	@Override
	public String recoverPassword(Users users) {
		String res = userDao.recoverPass(users);
		if (res.equals("invalid")) {
			return "Sorry. You entered invalid details.!!!";
		} else if (res.equals("fail")) {
			return "Something went wrong";
		} else if (res.length() == 7) {
			return "Your Password is: " + res + "\n Now Login using this Password.";
		} else {
			return res;
		}

	}

}
