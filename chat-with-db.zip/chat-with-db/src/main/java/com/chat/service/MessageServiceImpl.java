package com.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chat.dao.MessageDao;
import com.chat.model.Message;
import com.chat.model.Users;

@Service
public class MessageServiceImpl implements MessageService {

	@Autowired
	MessageDao messageDao;

	@Autowired
	FriendService friendService;

	@Override
	public String sendMessage(String fromId, String toId, String message) {
		boolean res = messageDao.sendMessageToSingleUser(fromId, toId, message);
		if (res) {
			return "Sent message.";
		} else {
			return "Message not sent.!!!";
		}
	}

	@Override
	public List<Message> getChatMsg(String fromId, String toId, String reqMsg) {
		return messageDao.showChatMsg(fromId, toId, reqMsg);
	}

	@Override
	public String checkOldMsg(String fromId, String toId) {
		if (messageDao.checkOldMsg(fromId, toId)) {
			return "View Old Message";
		} else {
			return null;
		}
	}

	@Override
	public List<Users> getUserFriends(int groupId, String userid) {
		// TODO Auto-generated method stub
		return null;
	}

}
