package com.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chat.dao.FriendDao;
import com.chat.model.Users;

@Service
public class FriendServiceImpl implements FriendService {

	@Autowired
	FriendDao friendDao;

	@Override
	public List<Users> getSearchFriend(String fullname,String userid) {
		Users users = new Users();

		// when any friend is search by user then
		// current logged in users name does not appear on the screen
		List<Users> friendList = friendDao.getSearchFriend(fullname);
		for (int i = 0; i < friendList.size(); i++) {
			users = friendList.get(i);
			if (users.getUserid().equals(userid)) {
				friendList.remove(i);
			}
		}
		return friendList;
	}

	@Override
	public String addFriend(String friendWith, String friendOf) {
		return friendDao.addFriend(friendWith, friendOf);
	}

	@Override
	public List<Users> userFriendList(String uid) {
		return friendDao.userFriendList(uid);
	}

	@Override
	public String acceptFriendRequest(String friendWith, String friendOf) {
		return friendDao.acceptFriendRequest(friendWith, friendOf);
	}

	@Override
	public List<Users> showfriendRequestLst(String friendOf) {
		return friendDao.showFriendRequestList(friendOf);
	}

	@Override
	public String unFriendTo(String unfriendTo, String unfriendFrom) {
		return friendDao.unFriend(unfriendTo, unfriendFrom);
	}
}
