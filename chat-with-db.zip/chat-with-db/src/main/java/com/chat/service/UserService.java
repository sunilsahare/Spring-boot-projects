package com.chat.service;

import com.chat.model.Users;

public interface UserService {

	public String addUser(Users users);
	public String loginUser(String email, String password);
	public String recoverPassword(Users users);
    public String changePassword(String nPass, String email, String cPass);
}
