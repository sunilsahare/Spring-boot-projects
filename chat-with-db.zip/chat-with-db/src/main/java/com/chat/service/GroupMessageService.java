package com.chat.service;

import java.util.List;

import com.chat.model.Group;
import com.chat.model.Message;
import com.chat.model.Users;

public interface GroupMessageService {
	public boolean createChatGroup(String userid, String groupName,String [] memberId);
	public List<Group> showGroupList(String userid);
	public List<Group> showGroupMembers(int groupId);
	public String sendGroupMessage(String fromId, List<Group> member, String message);
	boolean removeMemberFromGroup(int groupid, String memberId);
	public List<Message> getGroupChatMsg(int groupId, String requestMsg);
	public String checkOldGroupMsg(int groupId);
	boolean addNewGroupMemberInGroup(int groupId, String[] memberid);
	boolean removeGroup(int groupId);
	public List<Users> getUserFriendlist(String friendOfId, int groupId);
}
