package com.chat.service;

import java.util.List;

import com.chat.model.Users;

public interface FriendService {
	public List<Users> userFriendList(String uid);
	public String addFriend(String friendWith, String friendOf);
	public String acceptFriendRequest(String friendWith, String friendOf);
	public List<Users> showfriendRequestLst(String friendOf);
	public String unFriendTo(String unfriendTo, String unfriendFrom);
	public List<Users> getSearchFriend(String fullname, String userid);
}
