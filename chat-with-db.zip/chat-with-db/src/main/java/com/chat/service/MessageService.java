package com.chat.service;

import java.util.List;

import com.chat.model.Group;
import com.chat.model.Message;
import com.chat.model.Users;

public interface MessageService {

	public String sendMessage(String fromId, String toId,String message);
	public List<Users> getUserFriends(int groupId, String userid);
	public String checkOldMsg(String fromId, String toId);
	public List<Message> getChatMsg(String fromId, String toId, String reqMsg);
	
}
