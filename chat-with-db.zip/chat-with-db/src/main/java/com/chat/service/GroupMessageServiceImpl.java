package com.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chat.dao.GroupMessageDao;
import com.chat.model.Group;
import com.chat.model.Message;
import com.chat.model.Users;

@Service
public class GroupMessageServiceImpl implements GroupMessageService {

	@Autowired
	GroupMessageDao groupMessageDao;

	@Autowired
	FriendService friendService;

	@Override
	public boolean createChatGroup(String userid, String groupName, String[] memberId) {
		return groupMessageDao.createGroup(userid, groupName, memberId);
	}

	@Override
	public List<Group> showGroupList(String userid) {
		return groupMessageDao.displayGroups(userid);
	}

	@Override
	public List<Group> showGroupMembers(int groupId) {
		return groupMessageDao.showGroupMembers(groupId);
	}

	@Override
	public String sendGroupMessage(String fromId, List<Group> toMembers, String message) {
		boolean res = groupMessageDao.sendGroupMessage(fromId, toMembers, message);
		if (res) {
			return "Message Sent";
		} else {
			return "Message not sent.!!!";
		}
	}

	@Override
	public List<Message> getGroupChatMsg(int groupId, String requestMsg) {
		return groupMessageDao.showGroupChatMsg(groupId, requestMsg);
	}

	@Override
	public boolean removeMemberFromGroup(int groupId, String memberId) {
		return groupMessageDao.removeGroupMember(groupId, memberId);
	}

	@Override
	public boolean addNewGroupMemberInGroup(int groupId, String[] memberid) {
		return groupMessageDao.addNewGroupMember(groupId, memberid);
	}

	@Override
	public String checkOldGroupMsg(int groupId) {
		if (groupMessageDao.checkOldGroupMsg(groupId)) {
			return "View All Message";
		} else {
			return null;
		}
	}

	@Override
	public boolean removeGroup(int groupId) {
		return groupMessageDao.removeGroup(groupId);
	}

	@Override
	public List<Users> getUserFriendlist(String friendOfId, int groupId) {
		List<Users> friendList = groupMessageDao.userFriendList(friendOfId);
		List<Group> groupMembers = groupMessageDao.showGroupMembers(groupId);

		Users user = null;
		Group group = null;

		// generating friend list of friends who are not in group
		for(int i=0;i<groupMembers.size();i++) {
			group = groupMembers.get(i);
			for(int j=0;j<friendList.size();j++) {
				user = friendList.get(j);
				if (group.getUserId().equals(user.getUserid())) {
					friendList.remove(j);
					System.out.println(user);
				}
			}
		}
		return friendList;
	}

}
