package com.chat.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.chat.model.Users;
import com.chat.service.FriendService;

@Controller
public class FriendController {

	@Autowired
	FriendService friendService;
	
	@RequestMapping("searchFriend")
	public String searchFriend(@RequestParam("fullname") String fullname, @RequestParam("userid") String userid, ModelMap modelMap) {
		List<Users> searchFriend = friendService.getSearchFriend(fullname, userid);
		modelMap.addAttribute("searchFriend", searchFriend);
		return "chat/searchFriend";
	}

	@RequestMapping("/addFriend")
	public String addFriend(@RequestParam("friendOf") String friendOf, @RequestParam("friendWith") String friendWith,
			ModelMap modelMap, HttpSession session) {
		String msg = friendService.addFriend(friendWith, friendOf);
		session.setAttribute("msg", msg);
		// this will display the friend request list
		session.setAttribute("friendRequestList", friendService.showfriendRequestLst(friendOf));
		return "redirect:friendList?friendOf="+session.getAttribute("userid");
	}

	// disply friend list to the user
	@RequestMapping("/friendList")
	public String userFriendList(@RequestParam("friendOf") String friendOf, ModelMap modelMap, HttpSession session) {
		session.setAttribute("friendList", friendService.userFriendList(friendOf));
		// this will display the friend request list
		session.setAttribute("friendRequestList", friendService.showfriendRequestLst(friendOf));
		
		//this session removed because this session display the allthe chat of user
		//so when user click on new chat then it should display all chat.
		session.removeAttribute("msgs");
		return "chat/userFriendList";
	}

	// process friend request either accept or deny
	@RequestMapping("/accept-request")
	public String processFriendRequest(@RequestParam("friendOf") String friendOf,
			@RequestParam("friendWith") String friendWith, ModelMap modelMap, HttpSession session) {
		String msg = friendService.acceptFriendRequest(friendWith, friendOf);
		session.setAttribute("msg", msg);
		// this will display the friend request list
		session.setAttribute("friendRequestList", friendService.showfriendRequestLst(friendOf));
		return "redirect:friendList?friendOf="+session.getAttribute("userid");
	}

	@RequestMapping("/unfriend")
	public String unfriend(@RequestParam("unfriendTo") String unfriendTo, @RequestParam("unfriendFrom") String unfriendFrom, ModelMap modelMap, HttpSession session) {
		String msg = friendService.unFriendTo(unfriendTo, unfriendFrom);
		modelMap.addAttribute("msg", msg);
		return "redirect:friendList?friendOf="+session.getAttribute("userid");
	}
	
}
