package com.chat.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.chat.dao.AdminDao;
import com.chat.dao.UserDao;
import com.chat.model.Users;
import com.chat.service.FriendService;
import com.chat.service.UserService;

@Controller
public class HomeController {

	@Autowired
	UserService userService;
	
	@Autowired
	UserDao userDao;
	
	@Autowired
	AdminDao admin;

	@Autowired
	FriendService friendService;
	
	@RequestMapping("/")
	public String showHomePage() {
		return "index";
	}

	@RequestMapping("/showReg")
	public String showRegisterPage() {
		return "login/register";
	}

	@RequestMapping("/register")
	public String registerUser(@ModelAttribute("Users") Users users, ModelMap modelMap) {
		String msg = userService.addUser(users);
		modelMap.addAttribute("msg", msg);
		return "index";
	}

	@RequestMapping("showLogin")
	public String showLoginPage() {
		return "login/login";
	}

	@RequestMapping("/login")
	public String checkloginInfo(@RequestParam("userid") String userid, @RequestParam("password") String password, ModelMap modelMap, HttpSession session) {
		String userType = userService.loginUser(userid, password);
		
		if (userType.equals("user")) {
			Users userInfo = userDao.userInfo(userid);
//			String userInfo = userDao.userInfo(userid);
			session.setAttribute("userid", userid);
			session.setAttribute("userInfo", userInfo);
			//this will display the friend request list
			session.setAttribute("friendRequestList", friendService.showfriendRequestLst(userid));
			return "redirect:friendList?friendOf="+session.getAttribute("userid");
		} 
		else if (userType.equals("admin")){
			Users user = userDao.userInfo(userid);
			session.setAttribute("userid", userid);
//			session.setAttribute("userInfo", user);
			List<Users> allUsers = admin.getAllUsers();
			modelMap.addAttribute("AllUsers", allUsers);
			return "chat/admin-dashboard";
		}
		else if (userType.equals("not-found")){
			modelMap.addAttribute("msg", "Invalid Username or password.!!!");
			return "login/login";
		}
		else {
			modelMap.addAttribute("msg", userType);
			return "login/login";
		}
		
	}

	
	// logout current user
	@RequestMapping("/logoutUser")
	public String logoutUser(HttpSession session, Model model) {
		if (session.getAttribute("userid") != null) {
			session.invalidate();
			model.addAttribute("msg", "Successfully Log out.");
			return "index";
		} else {
			model.addAttribute("msg", "You are not Logged in.!!!");
			return "index";
		}

	}

	// display change password screen
	@RequestMapping("/changePassword")
	public String showChangePassForm() {
		return "login/change-pass";
	}

	// Change Password
	@RequestMapping("/changePass")
	public String changeCurrentPass(@RequestParam("userid") String userid,
			@RequestParam("nPass") String nPass, @RequestParam("cPass") String cPass,
			HttpSession session) {
		String res = userService.changePassword(nPass, userid, cPass);
		if (res.equals("success")) {
			session.setAttribute("msg", "Password Changed Successfully.");
		} 
		else if (res.equals("fail")) {
			session.setAttribute("msg", "Invalid details!!! Please enter Valid details.");
		}
		else {
			session.setAttribute("msg", res);
		}
//		return "redirect:friendList?friendOf="+session.getAttribute("userid");
		return "redirect:/changePassword";
	}

	// forgot Password
	@RequestMapping("/recoverPass")
	public String recoverPass() {
		return "login/recoverPass";
	}
	
	@RequestMapping("/forgotPass")
	public String recoverForgotPass(@ModelAttribute("Users") Users users, ModelMap modelMap) {
		String res = userService.recoverPassword(users);
		modelMap.addAttribute("msg", res);
		return "login/login";
	}

}
