package com.chat.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chat.dao.UserDao;
import com.chat.model.Users;
import com.chat.service.FriendService;
import com.chat.service.MessageService;
import com.chat.service.UserService;

@Controller
public class MessageController {

	@Autowired
	MessageService messageService;

	@Autowired
	FriendService friendService;

	@Autowired
	UserDao userDao;
	
	// show msg page
	@RequestMapping("/showMsgPage")
	public String showMessagePage(@RequestParam("chatWith") String chatWith, @RequestParam("chatFrom") String chatFrom,
			HttpSession session,ModelMap modelMap) {
		session.setAttribute("chatWith", chatWith);
		session.setAttribute("chatFrom", chatFrom);
		Users friendInfo = userDao.userInfo(chatWith);
		modelMap.addAttribute("friendInfo", friendInfo);
		
		return "chat/chatPage";
	}

	// send message and display msg on chat box
	@RequestMapping("/send-message")
	@ResponseBody
	public void sendMsgToOneUser(@RequestParam("fromId") String fromId, @RequestParam("toId") String toId,
			@RequestParam("message") String message, HttpSession session) {
		messageService.sendMessage(fromId, toId, message);
	}

	@RequestMapping("/chat-box")
	public String chatBox(ModelMap modelMap, HttpSession session) {
		String fromId = (String) session.getAttribute("chatFrom");
		String toId = (String) session.getAttribute("chatWith");
		String msgs = (String) session.getAttribute("msgs");
		if(msgs==null) {
			modelMap.addAttribute("Msgs", messageService.getChatMsg(fromId, toId, "new"));
		}
		else {
			// get chat msg to display on screen
			modelMap.addAttribute("Msgs", messageService.getChatMsg(fromId, toId, "all"));
		}
		return "chat/chat-box";
	}

	@RequestMapping("/chat-box-all-msg")
	public String chatBoxOfAllMsg(ModelMap modelMap, HttpSession session) {
		session.setAttribute("msgs","allmsg");
		return "redirect:showMsgPage?chatWith="+session.getAttribute("chatWith")+"&chatFrom="+session.getAttribute("chatFrom");
	}

	
	@RequestMapping("/old-msg")
	@ResponseBody
	public String checkOldMsg(ModelMap modelMap, HttpSession session) {
		String fromId = (String) session.getAttribute("chatFrom");
		String toId = (String) session.getAttribute("chatWith");
		String oldMsg = messageService.checkOldMsg(fromId, toId);
		return oldMsg;
	}


}
