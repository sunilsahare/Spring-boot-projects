package com.chat.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chat.model.Group;
import com.chat.service.FriendService;
import com.chat.service.GroupMessageService;
import com.chat.service.MessageService;

@Controller
public class GroupController {

	@Autowired
	GroupMessageService groupMessageService;

	@Autowired
	FriendService friendService;

	// show create group page
	@RequestMapping("/show-create-group")
	public String showCreateGroupPage(@RequestParam("userid") String userid, ModelMap modelMap) {
		// add to modelmap
		modelMap.addAttribute("frndList", friendService.userFriendList(userid));
		return "chat/create-group";
	}

	// create group
	@RequestMapping("/create-group")
	public String createGroup(@RequestParam("userid") String userid, @RequestParam("groupName") String groupName,
			@RequestParam("memberId") String[] memberId, ModelMap modelMap, HttpSession session) {
		boolean group = groupMessageService.createChatGroup(userid, groupName, memberId);
		if (group) {
			modelMap.addAttribute("msg", "Group Created.");
		} else {
			modelMap.addAttribute("msg", "Group Creation failed.!!!");
		}
		return "redirect:friendList?friendOf=" + session.getAttribute("userid");
	}

	// display group list to user
	@RequestMapping("/show-group")
	public String showGroupList(@RequestParam("userid") String userid, ModelMap modelMap, HttpSession session) {
		modelMap.addAttribute("groupList", groupMessageService.showGroupList(userid));
		session.removeAttribute("requestMsg");
		return "chat/groupList";
	}

	// display group chat page to user
	@RequestMapping("/group-chat")
	public String showGroupMember(@RequestParam("groupId") int groupId, @RequestParam("groupName") String groupName,
			HttpSession session) {
		List<Group> groupMembers = groupMessageService.showGroupMembers(groupId);
		session.setAttribute("groupMembers", groupMembers);
		session.setAttribute("groupName", groupName);
		session.setAttribute("groupId", groupId);
		return "chat/groupChatPage";
	}

	// send message and display msg on chat box
	@RequestMapping("/send-group-msg")
	@ResponseBody
	public void sendGroupMsg(@RequestParam("fromId") String fromId, @RequestParam("toGroupId") int groupId,
			@RequestParam("message") String message, HttpSession session) {
		// get member list of group
		List<Group> members = groupMessageService.showGroupMembers(groupId);
		groupMessageService.sendGroupMessage(fromId, members, message);
	}

	@RequestMapping("/group-chat-box")
	public String showGroupChatMsg(ModelMap modelMap, HttpSession session) {
		int groupId = (Integer) session.getAttribute("groupId");
		// get group-chat msg to display on screen
		String requestMsg = (String) session.getAttribute("requestMsg");
		if (requestMsg == null) {
			modelMap.addAttribute("groupMsgs", groupMessageService.getGroupChatMsg(groupId, "new"));
		} else {
			modelMap.addAttribute("groupMsgs", groupMessageService.getGroupChatMsg(groupId, requestMsg));
		}
		return "chat/group-chat-box";
	}

	@RequestMapping("/group-chat-box-all-msg")
	public String groupChatBoxOfAllMsg(ModelMap modelMap, HttpSession session) {
		session.setAttribute("requestMsg", "all");
		System.out.println(session.getAttribute("groupId") + "----groupName------" + session.getAttribute("groupName"));
//		return "redirect:chat-box";
		return "redirect:group-chat?groupId=" + session.getAttribute("groupId") + "&groupName="
				+ session.getAttribute("groupName");
	}

	@RequestMapping("/remove-group-member")
	public String removeGroupmember(@RequestParam("groupId") int groupId, @RequestParam("memberId") String memberId,
			ModelMap modelMap) {
		boolean result = groupMessageService.removeMemberFromGroup(groupId, memberId);
		if (result) {
			modelMap.addAttribute("groupMembers", groupMessageService.showGroupMembers(groupId));
			modelMap.addAttribute("msg", "Member Removed.");
		} else {
			modelMap.addAttribute("msg", "Operation failed.!!!");
		}
		return "chat/groupChatPage";
	}

	@RequestMapping("/leave-group")
	public String leaveGroup(@RequestParam("groupId") int groupId, @RequestParam("memberId") String memberId,
			HttpSession session) {
		// this method also used to leave the group by the group member
		groupMessageService.removeMemberFromGroup(groupId, memberId);
		session.setAttribute("msg", "You are Successfully leave the group.");
//		session.setAttribute("groupId", groupId);
		return "redirect:friendList?friendOf=" + session.getAttribute("userid");
	}

	@RequestMapping("/remove-group")
	public String deleteGroup(@RequestParam("groupId") int groupId,
			HttpSession session) {
		if(groupMessageService.removeGroup(groupId)) {
			session.setAttribute("msg", "Group Removed Successfully");
		}
		else {
			session.setAttribute("msg", "Group not Removed.!!!");
		}
		return "redirect:show-group?userid=" + session.getAttribute("userid");
	}

	// display friend list to the group admin
	@RequestMapping("/show-add-member-page")
	public String userFriendList(@RequestParam("groupId") int groupId, @RequestParam("userId") String friendOf,
			ModelMap modelMap, HttpSession session) {
		session.setAttribute("friendList", groupMessageService.getUserFriendlist(friendOf, groupId));
		session.setAttribute("groupId", groupId);
		// this will display the friend request list
		session.setAttribute("friendRequestList", friendService.showfriendRequestLst(friendOf));
		return "chat/addGroupMember";
	}

	@RequestMapping("/add-member")
	public String addMemberInGroup(@RequestParam("userid") String userid, @RequestParam("groupId") int groupId,
			@RequestParam("memberId") String[] members, ModelMap modelMap, HttpSession session) {
		groupMessageService.addNewGroupMemberInGroup(groupId, members);
		// session.setAttribute("groupId", groupId);

		return "redirect:/show-group?userid=" + userid;
//		return "redirect:/group-chat?groupId="+groupId+"&groupName="+session.getAttribute("groupname");
	}

	@RequestMapping("/old-group-msg")
	@ResponseBody
	public String checkOldGroupMsg(ModelMap modelMap, HttpSession session) {
		int groupId = (Integer) session.getAttribute("groupId");
		String oldMsg = groupMessageService.checkOldGroupMsg(groupId);
		return oldMsg;
	}

}
