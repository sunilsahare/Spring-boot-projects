package com.chat.controller;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.chat.dao.AdminDao;
import com.chat.dao.UserDao;
import com.chat.model.Users;
import com.chat.util.EmailUtil;

@Controller
public class AdminController {

	@Autowired
	AdminDao admin;
	
	@Autowired
	EmailUtil email;

	@Autowired
	UserDao userDao;

	@RequestMapping("/all-users")
	public String getAllUsers(ModelMap modelMap) {
		List<Users> allUsers = admin.getAllUsers();
		modelMap.addAttribute("AllUsers", allUsers);
		return "chat/admin-dashboard";
	}

	@RequestMapping("/rm-user")
	public String removeUser(@RequestParam("userid") String userid, ModelMap modelMap) {
		// this will display users list
		modelMap.addAttribute("AllUsers", admin.getAllUsers());
		if (admin.removeUser(userid)) {
			modelMap.addAttribute("msg", "User Removed Successfully.");
		} else {
			modelMap.addAttribute("msg", "Sorry! User not removed.");
		}

//		return "chat/admin-dashboard";
		return "redirect:/all-users";
	}

	@RequestMapping("/change-status")
	public String changeLoginStatus(@RequestParam("userid") String userid,
			@RequestParam("newStatus") String newLoginSts, ModelMap modelMap) {
		//this will display users list
		modelMap.addAttribute("AllUsers", admin.getAllUsers());
		
		Users userInfo = userDao.userInfo(userid);
		
		String msgBody = null;
		if (admin.changeLoginStatus(newLoginSts, userid) && newLoginSts.equals("active")) {
			modelMap.addAttribute("msg", "User Activated.");
			msgBody = "Hello "+userInfo.getFullName()+", your account of Web Chat Messanger is now activated by Admin.\n"+new Date();
		} 
		else {
			msgBody = "Hello "+userInfo.getFullName()+", your account of Web Chat Messanger is Deactivated by Admin. Please conatact with Admin for further details.\n"+new Date();
			modelMap.addAttribute("msg", "User deatcivated Successfully");
		}
		
		//send msg to user
		email.sendEmail(userInfo.getEmail(), "Account Activation Status", msgBody);
		return "redirect:all-users";
//		return "chat/admin-dashboard";
	}
	
	
	

}
