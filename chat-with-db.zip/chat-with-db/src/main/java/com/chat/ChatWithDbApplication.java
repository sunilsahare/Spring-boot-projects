package com.chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatWithDbApplication.class, args);
	}

}
