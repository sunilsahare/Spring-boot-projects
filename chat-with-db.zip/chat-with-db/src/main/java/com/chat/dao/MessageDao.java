package com.chat.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.chat.dbconnection.DbConnection;
import com.chat.model.Message;

@Component
public class MessageDao {

	public MessageDao() {

	}

	// database Connection
	Connection con = DbConnection.getCon();

	// send message to single user
	public boolean sendMessageToSingleUser(String fromId, String toId, String message) {
		CallableStatement cst;

		try {
			cst = con.prepareCall("{call sendMsg(?,?,?,?)}");
			cst.setInt(1, new Random().nextInt(9999));
			cst.setString(2, fromId);
			cst.setString(3, toId);
			cst.setString(4, message);

			int i = cst.executeUpdate();
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// display chat message in chat box
	public List<Message> showChatMsg(String fromId, String toId, String reqMsg) {
		List<Message> list = new ArrayList<Message>();
		Message msg;
		String q = null;

		if (reqMsg.equals("new")) {
			q = "select * from msgView where group_id=0 and (from_id=? and to_id=? or from_id=? and to_id=?)";
		} else {
			q = "select * from message where from_id=? and to_id=? and group_id=0 or from_id=? and to_id=? and group_id=0 order by timestamp";
		}

		PreparedStatement pst;

		try {
			pst = con.prepareStatement(q);
			pst.setString(1, fromId);
			pst.setString(2, toId);
			pst.setString(3, toId);
			pst.setString(4, fromId);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				msg = new Message(rs.getInt("id"), rs.getString("from_id"), rs.getString("to_id"),
						rs.getString("message"), rs.getString("timestamp"), rs.getInt("group_id"));
				list.add(msg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}

	// this method is to check that the logged in user has the old message
	// if this method return true then we will display the old message button on the
	// page
	public boolean checkOldMsg(String fromId, String toId) {
		PreparedStatement pst;
		try {
			String qr = "select * from message where group_id=0 and month(timestamp) = month(now()) - 2 and (from_id=? and to_id=?  or from_id=? and to_id=?) order by timestamp";

			pst = con.prepareStatement(qr);
			pst.setString(1, fromId);
			pst.setString(2, toId);
			pst.setString(3, toId);
			pst.setString(4, fromId);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	
}
