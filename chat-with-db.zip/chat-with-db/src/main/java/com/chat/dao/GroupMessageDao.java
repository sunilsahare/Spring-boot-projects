package com.chat.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.chat.dbconnection.DbConnection;
import com.chat.model.Group;
import com.chat.model.Message;
import com.chat.model.Users;
import com.fasterxml.jackson.databind.util.ClassUtil.Ctor;

@Component
public class GroupMessageDao {

	public GroupMessageDao() {

	}

	// database Connection
	Connection con = DbConnection.getCon();

	// create group and add member in the group
	public boolean createGroup(String createdBy, String groupName, String[] memberid) {
		CallableStatement cst;
		try {
			int groupId = new Random().nextInt(9999);
			cst = con.prepareCall("{call createGroup(?,?,?)}");
			cst.setInt(1, groupId);
			cst.setString(2, createdBy);
			cst.setString(3, groupName);

			int i = cst.executeUpdate();
			if (i > 0) {
				cst = con.prepareCall("{call addMemberInGroup(?,?,?)}");
				// add ourself in group
				cst.setInt(1, groupId);
				cst.setInt(2, new Random().nextInt(9999));
				cst.setString(3, createdBy); // createdby means group admin userid
				// add to the batch
				cst.addBatch();

				// add selected member in group
				for (String member : memberid) {
					cst.setInt(1, groupId);
					cst.setInt(2, new Random().nextInt(9999));
					cst.setString(3, member);
					// add to the batch
					cst.addBatch();
				}
				// commit changes in db
				int[] result = cst.executeBatch();

				if (result.length > 0) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// show group list to users
	public List<Group> displayGroups(String userid) {
		List<Group> list = new ArrayList<Group>();
		Group group;

		PreparedStatement pst;

		try {
			pst = con.prepareStatement("select * from groupInfoView where user_id=?");
			pst.setString(1, userid);

			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				group = new Group();
				group.setGroupId(rs.getInt("group_id"));
				group.setCreatedBy(rs.getString("created_by"));
				group.setCreatedDate(rs.getString("created_date"));
				group.setGroupName(rs.getString("group_name"));

				list.add(group);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// show group member list of group to users
	public List<Group> showGroupMembers(int groupId) {
		List<Group> list = new ArrayList<Group>();
		Group group;

		PreparedStatement pst;

		try {
			pst = con.prepareStatement("select * from groupInfoView where group_id=?");
			pst.setInt(1, groupId);

			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				group = new Group();
				group.setGroupId(rs.getInt("group_id"));
				group.setUserId(rs.getString("user_id"));
				group.setFullName(rs.getString("fullname"));
				group.setCreatedBy(rs.getString("created_by"));
				group.setCreatedDate(rs.getString("created_date"));
				list.add(group);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// send group message
	public boolean sendGroupMessage(String fromId, List<Group> toMembers, String message) {
		CallableStatement cst;
		try {
			cst = con.prepareCall("{call sendGroupMsg(?,?,?,?,?)}");
			// extract group member list to send them message
			for (Group member : toMembers) {
				if (member.getUserId().equals(fromId)) {
					continue;
				} else {
					cst.setInt(1, new Random().nextInt(9999));
					cst.setInt(2, member.getGroupId());
					cst.setString(3, fromId);
					cst.setString(4, member.getUserId());
					cst.setString(5, message);
					// add each record in batch
					cst.addBatch();
				}

			}

			// commit changes in db
			int[] i = cst.executeBatch();
			if (i.length > 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// display group chat message in chat box
	public List<Message> showGroupChatMsg(int groupId, String requestMsg) {
		List<Message> list = new ArrayList<Message>();
		Message msg;

		PreparedStatement pst;
		String qry = null;
		if (requestMsg.equals("new")) {
			qry = "select * from message where group_id=? and (month(timestamp) = month(now())-1 or month(timestamp) = month(now())) group by message order by timestamp";
		} else {
			qry = "select * from message where group_id=? group by message order by timestamp";
		}

		try {
			pst = con.prepareStatement(qry);
			pst.setInt(1, groupId);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				msg = new Message(rs.getInt("id"), rs.getString("from_id"), rs.getString("to_id"),
						rs.getString("message"), rs.getString("timestamp"), rs.getInt("group_id"));
				list.add(msg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}

	// this method is to check that the logged in user has the old message
	// if this method return true then we will display the old message button on the
	// page
	public boolean checkOldGroupMsg(int groupId) {
		PreparedStatement pst;
		try {
			String qr = "select * from message where group_id=? and (month(timestamp) = month(now())-2) group by message order by timestamp";

			pst = con.prepareStatement(qr);
			pst.setInt(1, groupId);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	//display users friend list to add member in group
	public List<Users> userFriendList(String userid) {
		Users user;
		List<Users> list = new ArrayList<Users>();
		try {
			String q = "select * from friendListView where friend_of_id=?";
			PreparedStatement pst = con.prepareStatement(q);
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				user = new Users();
				user.setUserid(rs.getString("userid"));
				user.setEmail(rs.getString("email"));
				user.setFullName(rs.getString("fullname"));
				user.setDob(rs.getString("dob"));
				user.setMobile(rs.getString("mobile"));
				user.setCity(rs.getString("city"));
				list.add(user);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// remove group member from the group
	public boolean removeGroupMember(Integer groupId, String memberId) {
		PreparedStatement pst;
		try {
			pst = con.prepareStatement("delete from group_member where group_id=? and user_id=?");
			pst.setInt(1, groupId);
			pst.setString(2, memberId);

			int i = pst.executeUpdate();
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// add new members in the group by the admin
	public boolean addNewGroupMember(int groupId, String[] memberid) {
		CallableStatement cst;
		try {
			cst = con.prepareCall("{call addMemberInGroup(?,?,?)}");
			// add selected member in group
			for (String member : memberid) {
				cst.setInt(1, groupId);
				cst.setInt(2, new Random().nextInt(9999));
				cst.setString(3, member);
				// add to the batch
				cst.addBatch();
			}
			// commit changes in db
			int[] result = cst.executeBatch();

			if (result.length > 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean removeGroup(int groupId) {
		PreparedStatement pst;
		try {
			pst = con.prepareStatement("delete from group_info where id=?");
			pst.setInt(1, groupId);

			int i = pst.executeUpdate();
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
