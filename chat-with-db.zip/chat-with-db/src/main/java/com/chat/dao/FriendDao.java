package com.chat.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.chat.dbconnection.DbConnection;
import com.chat.model.Users;

@Component
public class FriendDao {

	public FriendDao() {

	}

	// database Connection
	Connection con = DbConnection.getCon();

	// search friend list
	public List<Users> getSearchFriend(String fullname) {
		Users user;
		List<Users> list = new ArrayList<Users>();
		try {
			PreparedStatement pst = con.prepareStatement("select * from user_info where fullname=?");
			pst.setString(1, fullname);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				user = new Users();
				user.setUserid(rs.getString("userid"));
				user.setFullName(rs.getString("fullname"));
				list.add(user);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// users friend list
	public List<Users> userFriendList(String userid) {
		Users user;
		List<Users> list = new ArrayList<Users>();
		try {
			String q = " select * from friendListView where friend_of_id=?";
			PreparedStatement pst = con.prepareStatement(q);
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				user = new Users();
				user.setUserid(rs.getString("userid"));
				user.setEmail(rs.getString("email"));
				user.setFullName(rs.getString("fullname"));
				user.setDob(rs.getString("dob"));
				user.setMobile(rs.getString("mobile"));
				user.setCity(rs.getString("city"));
				list.add(user);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// add friend
	public String addFriend(String friendWith, String friendOf) {
		PreparedStatement pst;
		try {
			pst = con.prepareStatement("select * from friends where friend_of_id=? and friend_with=?");
			pst.setString(1, friendOf);
			pst.setString(2, friendWith);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				return "You already sent Friend Request.!!!";
			} else {
				pst = con.prepareStatement(
						"insert into friends(fid,friend_with,is_friend,request_status,friend_of_id)values(?,?,false,'pending',?)");
				pst.setInt(1, new Random().nextInt(9999));
				pst.setString(2, friendWith);
				pst.setString(3, friendOf);
				int i = pst.executeUpdate();
				if (i > 0) {
					return "Friend Request sent Successfully.";
				} else {
					return "Something went wrong.!!! Please try again.";
				}
			}
		} catch (Exception e) {
			return e.getMessage();
		}

	}

	// accept friend request
	public String acceptFriendRequest(String friendWith, String friendOf) {
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(
					"update friends set request_status='accept', is_friend=true where friend_of_id=? and friend_with=?");
			pst.setString(1, friendOf);
			pst.setString(2, friendWith);
			int i = pst.executeUpdate();
			if (i > 0) {
				// call this method to make the friends of each other
				addFriend(friendOf, friendWith);
				pst = con.prepareStatement(
						"update friends set request_status='accept', is_friend=true where friend_of_id=? and friend_with=?");
				pst.setString(1, friendWith);
				pst.setString(2, friendOf);
				i = pst.executeUpdate();
				if (i > 0) {
					return "Now you are Friends";
				} else {
					return "Something went wrong.!!! Please try again later.";
				}

			} else {
				return "Something went wrong.!!! Please try again.";
			}

		} catch (Exception e) {
			return e.getMessage();
		}

	}

	// users friend request list display on notification box
	public List<Users> showFriendRequestList(String userid) {
		Users user;
		List<Users> list = new ArrayList<Users>();
		try {
			String q = "select user_info.userid,user_info.fullname,user_info.dob,user_info.mobile,user_info.email,user_info.city,friends.request_status from user_info natural join friends where user_info.userid=friends.friend_of_id and friends.friend_with=? and friends.request_status='pending'";
			PreparedStatement pst = con.prepareStatement(q);
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				user = new Users();
				user.setUserid(rs.getString("userid"));
				user.setEmail(rs.getString("email"));
				user.setFullName(rs.getString("fullname"));
				user.setDob(rs.getString("dob"));
				user.setMobile(rs.getString("mobile"));
				user.setCity(rs.getString("city"));

				list.add(user);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	//method for unfriend
	public String unFriend(String unfriendTo, String unfriendFrom) {
		PreparedStatement pst;
		try {
			pst = con.prepareStatement("delete from friends where friend_with=? and friend_of_id=?");
			pst.setString(1, unfriendTo);
			pst.setString(2, unfriendFrom);
			int i = pst.executeUpdate();
			if (i>0) {
				return "You are successfully unfriend with, "+unfriendTo;
			} 
			else {
				return "Something went wrong!!! Please try again.";
			}
		} catch (Exception e) {
			return e.getMessage();
		}

	}

}
