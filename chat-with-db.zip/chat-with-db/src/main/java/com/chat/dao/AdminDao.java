package com.chat.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.chat.dbconnection.DbConnection;
import com.chat.model.Users;

@Component
public class AdminDao {

	public AdminDao() {

	}

	// database Connection
	Connection con = DbConnection.getCon();

	// Get user Information
	public List<Users> getAllUsers() {
		PreparedStatement pst;
		List<Users> userList = new ArrayList<Users>();
		Users users;
		try {

			pst = con.prepareStatement(
					"select user_info.userid,user_info.fullname,user_info.dob,user_info.mobile,user_info.email,user_info.city,user_info.regdate,users.loginstatus from user_info natural join users where user_info.userid=users.userid");
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				users = new Users();
				users.setUserid(rs.getString("userid"));
				users.setFullName(rs.getString("fullname"));
				users.setMobile(rs.getString("mobile"));
				users.setDob(rs.getString("dob"));
				users.setEmail(rs.getString("email"));
				users.setCity(rs.getString("city"));
				users.setLoginStatus(rs.getString("loginstatus"));
				users.setRegDate(rs.getString("regdate"));

				// added to the list
				userList.add(users);
			}
			return userList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean removeUser(String userid) {
		PreparedStatement pst;
		try {

			pst = con.prepareStatement("delete from users where userid=?");
			pst.setString(1, userid);
			int i = pst.executeUpdate();
			if (i > 0) {
//				return true;
				pst = con.prepareStatement("delete from friends where friend_with=?");
				pst.setString(1, userid);
				int j = pst.executeUpdate();
				if (j > 0) {
					return true;
				} else {
					return false;
				}
				
				
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean changeLoginStatus(String newStatus, String userid) {
		PreparedStatement pst;
		try {

			pst = con.prepareStatement("update users set loginstatus=? where userid=?");
			pst.setString(1, newStatus);
			pst.setString(2, userid);
			int i = pst.executeUpdate();
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
