package com.chat.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.chat.dbconnection.DbConnection;
import com.chat.model.Users;

@Component
public class UserDao {

	public UserDao() {

	}

	// database Connection
	Connection con = DbConnection.getCon();

	public String registerUser(Users users) {
		PreparedStatement pst;
		CallableStatement cst;
		try {
			pst = con.prepareStatement("select userid from users where userid=?");
            pst.setString(1, users.getUserid());
            
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
            	return "user-exist";
            }
            else {
            	cst = con.prepareCall("{call regProcedure(?,?,?,?,?,?,?,?,?,?)}");
            	cst.setString(1, users.getUserid());
    			cst.setString(2, users.getPassword());
    			cst.setInt(3, new Random().nextInt(9999));
				cst.setString(4, users.getFullName());
				cst.setString(5, users.getDob());
				cst.setString(6, users.getMobile());
				cst.setString(7, users.getEmail());
				cst.setString(8, users.getCity());
				cst.setString(9, users.getSecQuestion());
				cst.setString(10, users.getAnswer());
				
				int i = cst.executeUpdate();
				if(i>0) {
					return "success";
				}
				else {
					return "fail";
				}
            }
				
		} 
		catch (Exception e) {
			return e.getMessage();
		}
	}

	// validate user
	public String validateUser(String userid, String password) {
		PreparedStatement pst;
		try {
			pst = con.prepareStatement("select * from users where userid=? and password=? and loginstatus='active'");
            pst.setString(1, userid);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
            	if(userid.equals(rs.getString("userid")) && password.equals(rs.getString("password"))) {
            		return rs.getString("usertype");
            	}
            	else {
            		return "not-found";
            	}
            }
            else{
                return "not-found";
            }
		} 
		catch (Exception e) {
			return e.getMessage();
		}
	}

	// Change Password
	public String changePass(String nPass, String userid, String cPass) {
		PreparedStatement pst;

		try {

			pst = con.prepareStatement("update users set password=? where userid=? and password=?");
			pst.setString(1, nPass);
			pst.setString(2, userid);
			pst.setString(3, cPass);
			int i = pst.executeUpdate();
			if (i > 0) {
				// return true;
				return "success";
			} else {
				// return false;
				return "fail";
			}

		} catch (Exception e) {
			// e.printStackTrace();
			return e.getMessage();
		}
		// return false;
	}

	// Recover Password
	public String recoverPass(Users users) {
		PreparedStatement pst;

		try {
			
			pst = con.prepareStatement("select * from user_info where secque=? and ans=? and userid=?");
			pst.setString(1, users.getSecQuestion());
			pst.setString(2, users.getAnswer());
			pst.setString(3, users.getUserid());
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				// generate new password
				String mob = rs.getString("mobile");
				String newPass = "Z_$" + mob.substring(3, 7);

				// now store the new password
				pst = con.prepareStatement("update users set password=? where userid=?");
				pst.setString(1, newPass);
				pst.setString(2, users.getUserid());
				int i = pst.executeUpdate();
				if (i > 0) {
					return newPass;
				} else {
					return "fail";
				}

			} else {
				return "invalid";
			}

		} catch (Exception e) {
			return e.getMessage();
		}
	}

	// Get user Information
	public Users userInfo(String userid) {
		PreparedStatement pst;
		Users users = new Users();
		try {

			pst = con.prepareStatement("select * from user_info where userid=?");
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
//				return rs.getString("fullname");
				users.setUserid(rs.getString("userid"));
				users.setFullName(rs.getString("fullname"));
				users.setMobile(rs.getString("mobile"));
				users.setDob(rs.getString("dob"));
				users.setEmail(rs.getString("email"));
				users.setCity(rs.getString("city"));
			    return users;
			} 
			else {
				return null;
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
