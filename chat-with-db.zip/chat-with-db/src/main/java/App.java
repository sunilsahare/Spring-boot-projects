import java.util.List;

import com.chat.dao.GroupMessageDao;
import com.chat.model.Group;
import com.chat.model.Users;

public class App {

	public static void main(String[] args) {
		GroupMessageDao g = new GroupMessageDao();
		List<Group> groupMember = g.showGroupMembers(3775);
		List<Users> friendList = g.userFriendList("sunil123");

//		// sunil friend
//		for (Users u : friendList) {
//			System.out.println(u);
//		}

		System.out.println("-----------------------------------");

		// group member of cool buddies
		for (Group group : groupMember) {
			System.out.println(group);
		}
/*
		System.out.println("//----------Removed list------------------//");
		
		Users user = null;
		Group group = null;

		// getting friend list of friends who are not in group
		for(int i=0;i<groupMember.size();i++) {
			group = groupMember.get(i);
			for(int j=0;j<friendList.size();j++) {
				user = friendList.get(j);
				if (group.getUserId().equals(user.getUserid())) {
					friendList.remove(j);
					System.out.println(user);
				}
			}
		}

		System.out.println("**********************************");
		//New friend list
		for (Users u : friendList) {
			System.out.println(u);
		}
*/
	}

}
